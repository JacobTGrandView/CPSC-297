"use strict";
/*    Unit5 assn 2
*/
//Decalre variables here


// Add loop here   
// Add event handler here 

// If statement Here 